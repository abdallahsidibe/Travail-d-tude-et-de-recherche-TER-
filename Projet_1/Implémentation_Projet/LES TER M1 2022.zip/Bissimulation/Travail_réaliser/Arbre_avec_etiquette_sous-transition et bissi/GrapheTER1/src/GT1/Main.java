package GT1;

public class Main {

	public static void main(String[] args) {
		Tree tree = new Tree();
		System.out.println(tree.noeuds.size());
		System.out.println("----------------------------");
		tree.Affichage();
		System.out.println("----------------------------");
		tree.MiniBisi();
		// Transition t = new Transition();
	}

}
