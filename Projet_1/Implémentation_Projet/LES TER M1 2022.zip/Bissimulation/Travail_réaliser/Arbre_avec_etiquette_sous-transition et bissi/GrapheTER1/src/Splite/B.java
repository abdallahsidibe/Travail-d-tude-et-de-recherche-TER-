package Splite;

import java.util.ArrayList;

import GT1.Node;

public class B {
	public ArrayList<Node> pi = new ArrayList<Node>();
}
