package GT1;

import java.util.ArrayList;

public class Transition {
	/*
	Liste d'etiquette pour un noeud et une transition
	 */
	public ArrayList<String> etiquettes = new ArrayList<String>();
	public Node n2;
}