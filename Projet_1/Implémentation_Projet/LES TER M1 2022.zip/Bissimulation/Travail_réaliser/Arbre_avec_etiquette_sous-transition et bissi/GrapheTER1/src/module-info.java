module GrapheTER1 {
}